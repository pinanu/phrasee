describe('Login page', () => {
 
    it('logs in to phrasee with valid user credentials', () =>{
       cy.login()
        })
    })